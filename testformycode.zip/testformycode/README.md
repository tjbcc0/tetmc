# XMRig

[![Github All Releases](https://img.shields.io/github/downloads/testformycode/testformycode/total.svg)](https://github.com/testformycode/testformycode/releases)
[![GitHub release](https://img.shields.io/github/release/testformycode/testformycode/all.svg)](https://github.com/testformycode/testformycode/releases)
[![GitHub Release Date](https://img.shields.io/github/release-date/testformycode/testformycode.svg)](https://github.com/testformycode/testformycode/releases)
[![GitHub license](https://img.shields.io/github/license/testformycode/testformycode.svg)](https://github.com/testformycode/testformycode/blob/master/LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/testformycode/testformycode.svg)](https://github.com/testformycode/testformycode/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/testformycode/testformycode.svg)](https://github.com/testformycode/testformycode/network)

XMRig is a high performance, open source, cross platform RandomX, KawPow, CryptoNight and [GhostRider](https://github.com/testformycode/testformycode/tree/master/src/crypto/ghostrider#readme) unified CPU/GPU miner and [RandomX benchmark](https://testformycode.com/benchmark). Official binaries are available for Windows, Linux, macOS and FreeBSD.

## Mining backends
- **CPU** (x86/x64/ARMv7/ARMv8)
- **OpenCL** for AMD GPUs.
- **CUDA** for NVIDIA GPUs via external [CUDA plugin](https://github.com/testformycode/testformycode-cuda).

## Download
* **[Binary releases](https://github.com/testformycode/testformycode/releases)**
* **[Build from source](https://testformycode.com/docs/miner/build)**

## Usage
The preferred way to configure the miner is the [JSON config file](https://testformycode.com/docs/miner/config) as it is more flexible and human friendly. The [command line interface](https://testformycode.com/docs/miner/command-line-options) does not cover all features, such as mining profiles for different algorithms. Important options can be changed during runtime without miner restart by editing the config file or executing [API](https://testformycode.com/docs/miner/api) calls.

* **[Wizard](https://testformycode.com/wizard)** helps you create initial configuration for the miner.
* **[Workers](http://workers.testformycode.info)** helps manage your miners via HTTP API.

## Donations
* Default donation 1% (1 minute in 100 minutes) can be increased via option `donate-level` or disabled in source code.
* XMR: `48edfHu7V9Z84YzzMa6fUueoELZ9ZRXq9VetWzYGzKt52XU5xvqgzYnDK9URnRoJMk1j8nLwEVsaSWJ4fhdUyZijBGUicoD`

## Developers
* **[testformycode](https://github.com/testformycode)**
* **[sech1](https://github.com/SChernykh)**

## Contacts
* support@testformycode.com
* [reddit](https://www.reddit.com/user/XMRig/)
* [twitter](https://twitter.com/testformycode_dev)
