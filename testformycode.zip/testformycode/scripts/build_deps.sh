#!/bin/sh -e

./build.uv.sh
./build.hwloc.sh
./build.openssl3.sh